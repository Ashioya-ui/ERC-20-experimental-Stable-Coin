Spectrum Protocol - Phase 4 work in progress (2026-10-17)

repo/            the code at the last commit, to browse
spectrum.bundle  the full git history

Restore a working copy:
  git clone spectrum.bundle spectrum && cd spectrum
  git checkout phase-4-hardening
  git submodule update --init --recursive
  forge test

Read repo/audit/wip/STATUS.md first: what is done, what is left, and what must happen before mainnet.
Nothing here has been deployed. Do not deploy to mainnet yet.
